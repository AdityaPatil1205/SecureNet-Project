# Wire protocol

A frame contains a four-byte unsigned payload length in network byte order, followed by exactly that many bytes of UTF-8 JSON. Valid payload lengths are 1 through 65,536 bytes. Both header and body are read/written in loops to handle partial socket operations and `EINTR`. A zero or oversized frame is rejected; a truncated frame closes the connection.

Requests use fields such as `request_id`, `action`, `token`, `username`, and `password`. Responses include `request_id`, `success`, `code`, and `message`, plus operation-specific fields. The request ID is limited to 128 bytes; action is required and limited to 64 bytes. Clients must not trust client-side role fields; the server resolves roles from session state.

Example request JSON: `{"request_id":"demo-1","action":"status"}`.
