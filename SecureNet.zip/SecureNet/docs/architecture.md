# Architecture and concurrency

The accept loop owns the listening socket and accepts IPv4 TCP connections. Each accepted descriptor is submitted to a bounded `ThreadPool`; if its queue is full, the connection is immediately sent a `busy` response and closed. Workers apply socket read/write timeouts and process length-prefixed frames. Shared SQLite access is protected by the `Database` mutex. Session, block-list, and rate-limit maps share a separate `Security` mutex. Counters are atomics.

The design favors explicit ownership: the worker closes each accepted client descriptor; the pool drains queued tasks during shutdown; database statements are finalized after each operation. A single SQLite connection is used and serialized under a mutex.

The current server's stop hook exists for controlled embedding, but the command-line executable does not install a signal handler. Ctrl+C terminates the process; signal-safe graceful shutdown remains future work.
