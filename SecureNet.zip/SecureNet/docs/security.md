# Security notes

- Passwords are hashed with OpenSSL `EVP_PBE_scrypt` using random 16-byte salts, scrypt N=16384/r=8/p=1, and a 32 MiB maximum-memory setting. Password hashes, not plaintext passwords, are stored in SQLite.
- Session tokens are generated with OpenSSL `RAND_bytes`, kept in memory, and expire after one hour.
- SQLite calls use prepared statements and bound values. Audit rows do not contain passwords, hashes, or bearer tokens.
- Authorization is server-side; `get_stats`, `get_audit_logs`, and `update_policy` require admin sessions.
- The default listener is `127.0.0.1`. There is no TLS; use only on localhost or a trusted isolated development network.
- Exact IPv4 blocking and rate limiting are process-local. This is not DDoS protection.
- Demo credentials are publicly documented for local use and must not be used in a deployed service.
