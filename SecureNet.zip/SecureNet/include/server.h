#pragma once
#include "database.h"
#include "security.h"
#include "thread_pool.h"
#include <atomic>
#include <cstdint>
#include <string>
#include <mutex>
namespace sn {
class Server {
 public: Server(std::string host,std::uint16_t port,std::string db_path,std::size_t workers=4,std::size_t queue=128);
  int run(); void stop();
 private: void handle(int fd,std::string ip); std::string process(const std::string&,const std::string&);
  std::string host_;std::uint16_t port_;Database db_;Security security_;ThreadPool pool_;std::atomic<bool> stopping_{false};std::atomic<unsigned long long> requests_{0},success_{0},rejected_{0},auth_fail_{0},rate_hits_{0},active_{0};
};
}
