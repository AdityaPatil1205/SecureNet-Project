#pragma once
#include <condition_variable>
#include <functional>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>
namespace sn {
class ThreadPool {
 public:
  ThreadPool(std::size_t workers, std::size_t capacity);
  ~ThreadPool();
  bool submit(std::function<void()> task);
  void shutdown();
  ThreadPool(const ThreadPool&)=delete; ThreadPool& operator=(const ThreadPool&)=delete;
 private:
  void run(); std::mutex m_; std::condition_variable cv_; std::queue<std::function<void()>> q_;
  std::vector<std::thread> workers_; std::size_t capacity_; bool stopping_=false;
};
}
