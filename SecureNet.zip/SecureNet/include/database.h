#pragma once
#include <sqlite3.h>
#include <mutex>
#include <string>
#include <vector>
namespace sn {
struct User { std::string username, hash, role; bool active=false; };
struct AuditEvent { std::string ip, username, type, action, outcome; };
class Database {
 public:
  explicit Database(const std::string& path); ~Database();
  bool create_user(const std::string& username,const std::string& hash,const std::string& role);
  bool get_user(const std::string& username,User& user);
  bool audit(const AuditEvent& e);
  std::string recent_audit(int limit=20);
  sqlite3* raw() { return db_; }
 private: sqlite3* db_=nullptr; std::mutex m_;
};
}
