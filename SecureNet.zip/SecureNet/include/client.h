#pragma once
#include <string>
namespace sn { int run_client(const std::string& host,int port,const std::string& request); }
