#pragma once
#include <boost/property_tree/ptree.hpp>
#include <cstdint>
#include <string>
namespace sn {
constexpr std::uint32_t MAX_FRAME_SIZE = 64 * 1024;
using Json = boost::property_tree::ptree;
bool read_frame(int fd, std::string& payload, std::string& error);
bool write_frame(int fd, const std::string& payload, std::string& error);
bool parse_json(const std::string& s, Json& out, std::string& error);
std::string json_escape(const std::string& s);
std::string json_string(const std::string& s);
std::string response(const std::string& id, bool success, const std::string& code,
                     const std::string& message, const std::string& extra = "");
std::string field(const Json& j, const std::string& key, const std::string& fallback = "");
} // namespace sn
