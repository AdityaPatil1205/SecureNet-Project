#pragma once
#include "database.h"
#include <chrono>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
namespace sn {
class Security {
 public:
  explicit Security(Database& db);
  bool login(const std::string& user,const std::string& pass,std::string& token,std::string& role);
  bool identity(const std::string& token,std::string& user,std::string& role);
  bool allowed_ip(const std::string& ip) const;
  bool rate_allowed(const std::string& ip);
  void set_blocked(const std::string& ip);
 private:
  struct Session{std::string user,role;std::chrono::steady_clock::time_point expires;};
  std::string hash_password(const std::string& pass,const std::string& salt) const;
  Database& db_; mutable std::mutex m_; std::unordered_map<std::string,Session> sessions_;
  std::unordered_map<std::string,std::pair<int,std::chrono::steady_clock::time_point>> rates_;
  std::unordered_set<std::string> blocked_; std::string dummy_hash_;
};
}
