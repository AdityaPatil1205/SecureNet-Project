#include "client.h"
#include "protocol.h"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <iostream>
namespace sn {int run_client(const std::string&host,int port,const std::string&request){int s=socket(AF_INET,SOCK_STREAM,0);if(s<0){perror("socket");return 1;}sockaddr_in a{};a.sin_family=AF_INET;a.sin_port=htons(static_cast<unsigned short>(port));if(inet_pton(AF_INET,host.c_str(),&a.sin_addr)!=1||connect(s,reinterpret_cast<sockaddr*>(&a),sizeof(a))<0){perror("connect");close(s);return 1;}std::string err,out;if(!write_frame(s,request,err)||!read_frame(s,out,err)){std::cerr<<"Protocol error: "<<err<<"\n";close(s);return 1;}std::cout<<out<<"\n";close(s);return 0;}}
