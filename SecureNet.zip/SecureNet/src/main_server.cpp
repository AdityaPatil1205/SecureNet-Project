#include "server.h"
#include <cstdlib>
#include <iostream>
#include <csignal>
int main(int argc,char**argv){std::string host="127.0.0.1",db="securenet.db";int port=5050;std::size_t workers=4,queue=128;try{for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--host"&&i+1<argc)host=argv[++i];else if(a=="--port"&&i+1<argc)port=std::stoi(argv[++i]);else if(a=="--db"&&i+1<argc)db=argv[++i];else if(a=="--workers"&&i+1<argc)workers=std::stoul(argv[++i]);else if(a=="--queue"&&i+1<argc)queue=std::stoul(argv[++i]);else if(a=="--help"){std::cout<<"Usage: securenet-server [--host 127.0.0.1] [--port 5050] [--db securenet.db] [--workers 4] [--queue 128]\n";return 0;}else throw std::runtime_error("unknown or incomplete option: "+a);}if(port<1||port>65535)throw std::runtime_error("port must be 1..65535");sn::Server s(host,static_cast<std::uint16_t>(port),db,workers,queue);return s.run();}catch(const std::exception&e){std::cerr<<"SecureNet: "<<e.what()<<"\n";return 1;}}
