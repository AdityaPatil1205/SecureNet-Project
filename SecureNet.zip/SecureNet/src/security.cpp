#include "security.h"
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/crypto.h>
#include <array>
#include <iomanip>
#include <sstream>
namespace sn {
static std::string hex(const unsigned char*p,std::size_t n){std::ostringstream o;o<<std::hex<<std::setfill('0');for(std::size_t i=0;i<n;++i)o<<std::setw(2)<<static_cast<unsigned>(p[i]);return o.str();}
Security::Security(Database& db):db_(db){dummy_hash_=hash_password("not-a-real-password","00112233445566778899aabbccddeeff");}
std::string Security::hash_password(const std::string& pass,const std::string& salt)const{std::array<unsigned char,16>s{};for(std::size_t i=0;i<s.size()&&i*2+1<salt.size();++i){unsigned int v=0;std::istringstream in(salt.substr(i*2,2));in>>std::hex>>v;s[i]=static_cast<unsigned char>(v);}std::array<unsigned char,32> out{};if(EVP_PBE_scrypt(pass.c_str(),pass.size(),s.data(),s.size(),16384,8,1,32*1024*1024,out.data(),out.size())!=1)return "";return salt+"$"+hex(out.data(),out.size());}
bool Security::login(const std::string& u,const std::string& p,std::string& token,std::string& role){User user;bool found=db_.get_user(u,user);std::string candidate;if(found&&user.hash.find('$')!=std::string::npos)candidate=hash_password(p,user.hash.substr(0,user.hash.find('$')));else candidate=hash_password(p,"00112233445566778899aabbccddeeff");bool good=found&&user.active&&!candidate.empty()&&candidate==user.hash;if(!good)return false;std::array<unsigned char,32>b{};if(RAND_bytes(b.data(),static_cast<int>(b.size()))!=1)return false;token=hex(b.data(),b.size());role=user.role;std::lock_guard<std::mutex>g(m_);sessions_[token]={user.username,user.role,std::chrono::steady_clock::now()+std::chrono::hours(1)};return true;}
bool Security::identity(const std::string&t,std::string&u,std::string&r){std::lock_guard<std::mutex>g(m_);auto i=sessions_.find(t);if(i==sessions_.end())return false;if(i->second.expires<std::chrono::steady_clock::now()){sessions_.erase(i);return false;}u=i->second.user;r=i->second.role;return true;}
bool Security::allowed_ip(const std::string&ip)const{std::lock_guard<std::mutex>g(m_);return blocked_.find(ip)==blocked_.end();}
void Security::set_blocked(const std::string&ip){std::lock_guard<std::mutex>g(m_);blocked_.insert(ip);}
bool Security::rate_allowed(const std::string&ip){std::lock_guard<std::mutex>g(m_);auto now=std::chrono::steady_clock::now();auto i=rates_.find(ip);if(i==rates_.end()){if(rates_.size()>4096){for(auto it=rates_.begin();it!=rates_.end();){if(now-it->second.second>std::chrono::minutes(2))it=rates_.erase(it);else ++it;}}rates_[ip]={1,now};return true;}if(now-i->second.second>=std::chrono::seconds(10)){i->second={1,now};return true;}if(i->second.first>=30)return false;++i->second.first;return true;}
}
