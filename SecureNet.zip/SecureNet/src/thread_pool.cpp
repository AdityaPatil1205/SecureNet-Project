#include "thread_pool.h"
#include <stdexcept>
namespace sn {
ThreadPool::ThreadPool(std::size_t n,std::size_t cap):capacity_(cap){if(!n||!cap)throw std::invalid_argument("worker count and queue capacity must be positive");for(std::size_t i=0;i<n;++i)workers_.emplace_back([this]{run();});}
ThreadPool::~ThreadPool(){shutdown();}
bool ThreadPool::submit(std::function<void()> task){std::lock_guard<std::mutex> g(m_);if(stopping_||q_.size()>=capacity_)return false;q_.push(std::move(task));cv_.notify_one();return true;}
void ThreadPool::shutdown(){{std::lock_guard<std::mutex> g(m_);if(stopping_)return;stopping_=true;}cv_.notify_all();for(auto& t:workers_)if(t.joinable())t.join();workers_.clear();}
void ThreadPool::run(){for(;;){std::function<void()> task;{std::unique_lock<std::mutex> lk(m_);cv_.wait(lk,[this]{return stopping_||!q_.empty();});if(stopping_&&q_.empty())return;task=std::move(q_.front());q_.pop();}try{task();}catch(...){}}}
}
