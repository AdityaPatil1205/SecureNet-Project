#include "client.h"
#include <iostream>
#include <string>
int main(int argc,char**argv){std::string host="127.0.0.1",request;int port=5050;for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--host"&&i+1<argc)host=argv[++i];else if(a=="--port"&&i+1<argc)port=std::stoi(argv[++i]);else if(a=="--request"&&i+1<argc)request=argv[++i];else if(a=="--help"){std::cout<<"Usage: securenet-client [--host 127.0.0.1] [--port 5050] --request '<JSON>'\n";return 0;}else{std::cerr<<"Unknown/incomplete argument: "<<a<<"\n";return 2;}}if(request.empty()){std::cerr<<"--request is required\n";return 2;}return sn::run_client(host,port,request);}
