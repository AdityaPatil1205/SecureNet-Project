#include "protocol.h"
#include <arpa/inet.h>
#include <sys/socket.h>
#include <boost/property_tree/json_parser.hpp>
#include <sstream>
#include <cerrno>
#include <cstring>
namespace sn {
static bool recv_all(int fd, char* p, std::size_t n) {
  std::size_t done=0; while(done<n) { auto r=::recv(fd,p+done,n-done,0); if(r==0) return false; if(r<0){if(errno==EINTR)continue;return false;} done+=static_cast<std::size_t>(r);} return true;
}
static bool send_all(int fd, const char* p, std::size_t n) {
  std::size_t done=0; while(done<n) { auto r=::send(fd,p+done,n-done,MSG_NOSIGNAL); if(r<0){if(errno==EINTR)continue;return false;} if(r==0)return false; done+=static_cast<std::size_t>(r);} return true;
}
bool read_frame(int fd, std::string& payload, std::string& error) {
  std::uint32_t net=0; if(!recv_all(fd,reinterpret_cast<char*>(&net),sizeof(net))){error="incomplete_header";return false;}
  std::uint32_t n=ntohl(net); if(n==0 || n>MAX_FRAME_SIZE){error="invalid_frame_size";return false;}
  payload.assign(n,'\0'); if(!recv_all(fd,payload.data(),n)){error="incomplete_payload";return false;} return true;
}
bool write_frame(int fd, const std::string& payload, std::string& error) {
  if(payload.empty() || payload.size()>MAX_FRAME_SIZE){error="invalid_frame_size";return false;}
  std::uint32_t n=htonl(static_cast<std::uint32_t>(payload.size()));
  if(!send_all(fd,reinterpret_cast<const char*>(&n),sizeof(n)) || !send_all(fd,payload.data(),payload.size())){error="socket_write_failed";return false;} return true;
}
bool parse_json(const std::string& s, Json& out, std::string& error) { try { std::istringstream is(s); boost::property_tree::read_json(is,out); return true; } catch(const std::exception&) { error="malformed_json"; return false; } }
std::string json_escape(const std::string& s) { std::string o; for(unsigned char c:s){switch(c){case '"':o+="\\\"";break;case '\\':o+="\\\\";break;case '\b':o+="\\b";break;case '\f':o+="\\f";break;case '\n':o+="\\n";break;case '\r':o+="\\r";break;case '\t':o+="\\t";break;default:if(c<0x20){const char*h="0123456789abcdef";o+="\\u00";o+=h[c>>4];o+=h[c&15];}else o+=static_cast<char>(c);}} return o; }
std::string json_string(const std::string& s){return "\""+json_escape(s)+"\"";}
std::string response(const std::string& id,bool ok,const std::string& code,const std::string& msg,const std::string& extra){return "{\"request_id\":"+json_string(id)+",\"success\":"+(ok?"true":"false")+",\"code\":"+json_string(code)+",\"message\":"+json_string(msg)+(extra.empty()?"":","+extra)+"}";}
std::string field(const Json& j,const std::string& k,const std::string& d){return j.get<std::string>(k,d);}
} // namespace sn
