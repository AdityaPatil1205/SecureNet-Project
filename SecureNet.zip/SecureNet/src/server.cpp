#include "server.h"
#include "protocol.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <boost/property_tree/json_parser.hpp>
#include <iostream>
#include <sstream>
#include <cstring>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <array>
#include <iomanip>
#include <stdexcept>
namespace sn {
Server::Server(std::string host,std::uint16_t port,std::string db,std::size_t workers,std::size_t queue):host_(std::move(host)),port_(port),db_(db),security_(db_),pool_(workers,queue){
 auto provision=[this](const std::string&u,const std::string&p,const std::string&r){User old;if(db_.get_user(u,old))return;unsigned char salt[16];if(RAND_bytes(salt,sizeof(salt))!=1)throw std::runtime_error("secure random generation failed");std::ostringstream ss;ss<<std::hex<<std::setfill('0');for(unsigned char c:salt)ss<<std::setw(2)<<static_cast<unsigned>(c); // hash format generated using the same scrypt parameters
 std::array<unsigned char,32> out{};if(EVP_PBE_scrypt(p.c_str(),p.size(),salt,sizeof(salt),16384,8,1,32*1024*1024,out.data(),out.size())!=1)throw std::runtime_error("password hashing failed");std::ostringstream h;h<<ss.str()<<"$"<<std::hex<<std::setfill('0');for(unsigned char c:out)h<<std::setw(2)<<static_cast<unsigned>(c);db_.create_user(u,h.str(),r);};
 provision("demo_user","ChangeMe_User_123!","user");provision("demo_admin","ChangeMe_Admin_123!","admin");
}
void Server::stop(){stopping_=true;}
int Server::run(){int s=::socket(AF_INET,SOCK_STREAM,0);if(s<0){perror("socket");return 1;}int yes=1;setsockopt(s,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));sockaddr_in addr{};addr.sin_family=AF_INET;addr.sin_port=htons(port_);if(inet_pton(AF_INET,host_.c_str(),&addr.sin_addr)!=1){std::cerr<<"Only numeric IPv4 bind addresses are supported\n";close(s);return 1;}if(bind(s,reinterpret_cast<sockaddr*>(&addr),sizeof(addr))<0||listen(s,128)<0){perror("bind/listen");close(s);return 1;}std::cout<<"SecureNet listening on "<<host_<<":"<<port_<<" (Ctrl+C to stop)\n";while(!stopping_){sockaddr_in peer{};socklen_t n=sizeof(peer);int c=accept(s,reinterpret_cast<sockaddr*>(&peer),&n);if(c<0){if(errno==EINTR)continue;if(stopping_)break;perror("accept");continue;}char ip[INET_ADDRSTRLEN]{};inet_ntop(AF_INET,&peer.sin_addr,ip,sizeof(ip));std::string client_ip(ip);active_++;if(!pool_.submit([this,c,client_ip]{handle(c,client_ip);active_--;})){active_--;std::string err;write_frame(c,response("",false,"busy","Server is busy; retry later"),err);close(c);}}close(s);pool_.shutdown();return 0;}
void Server::handle(int fd,std::string ip){timeval tv{5,0};setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv));std::string payload,err;while(read_frame(fd,payload,err)){requests_++;std::string out;if(!security_.allowed_ip(ip)){out=response("",false,"ip_blocked","Client address is blocked");rejected_++;db_.audit({ip,"","ip_blocked","","denied"});}else if(!security_.rate_allowed(ip)){out=response("",false,"rate_limited","Request rate limit exceeded");rate_hits_++;rejected_++;db_.audit({ip,"","rate_limited","","denied"});}else out=process(payload,ip);if(!write_frame(fd,out,err))break;}close(fd);}
std::string Server::process(const std::string&payload,const std::string&ip){Json j;std::string parseerr;if(!parse_json(payload,j,parseerr)){rejected_++;db_.audit({ip,"","invalid_json","","denied"});return response("",false,"invalid_json","Request must be valid JSON");}std::string id=field(j,"request_id"),action=field(j,"action");if(id.size()>128||action.empty()||action.size()>64){rejected_++;db_.audit({ip,"","invalid_request",action,"denied"});return response(id,false,"invalid_request","Required fields are missing or invalid");}
 std::string username,role,token=field(j,"token");bool authenticated=security_.identity(token,username,role);bool ok=false;std::string code="forbidden",msg="Operation is not permitted",extra="";
 if(action=="login"){std::string u=field(j,"username"),p=field(j,"password"),newtoken,newrole;if(u.size()>128||p.size()>256||u.empty()||p.empty()){code="invalid_request";msg="Username or password is invalid";}else if(security_.login(u,p,newtoken,newrole)){ok=true;code="ok";msg="Authenticated";extra="\"token\":"+json_string(newtoken)+",\"role\":"+json_string(newrole);username=u;role=newrole;}else{code="authentication_failed";msg="Invalid credentials";auth_fail_++;}}
 else if(action=="status"){ok=true;code="ok";msg="Server is running";extra="\"status\":\"running\"";}
 else if(action=="read_data"){if(!authenticated){code="unauthenticated";msg="Authentication required";}else{ok=true;code="ok";msg="Read operation permitted";extra="\"data\":{\"service\":\"SecureNet\",\"version\":\"1.0.0\"}";}}
 else if(action=="get_stats"){if(!authenticated){code="unauthenticated";msg="Authentication required";}else if(role!="admin"){code="forbidden";msg="Administrator role required";}else{ok=true;code="ok";msg="Statistics retrieved";std::ostringstream o;o<<"\"stats\":{\"requests\":"<<requests_.load()<<",\"successful\":"<<success_.load()<<",\"rejected\":"<<rejected_.load()<<",\"authentication_failures\":"<<auth_fail_.load()<<",\"rate_limit_violations\":"<<rate_hits_.load()<<",\"active_connections\":"<<active_.load()<<"}";extra=o.str();}}
 else if(action=="get_audit_logs"){if(!authenticated){code="unauthenticated";msg="Authentication required";}else if(role!="admin"){code="forbidden";msg="Administrator role required";}else{ok=true;code="ok";msg="Audit records retrieved";extra="\"events\":"+db_.recent_audit(20);}}
 else if(action=="update_policy"){if(!authenticated){code="unauthenticated";msg="Authentication required";}else if(role!="admin"){code="forbidden";msg="Administrator role required";}else{std::string block=field(j,"block_ip");in_addr a{};if(inet_pton(AF_INET,block.c_str(),&a)!=1){code="invalid_request";msg="block_ip must be a valid IPv4 address";}else{security_.set_blocked(block);ok=true;code="ok";msg="IPv4 address blocked";}}}
 else {code="unknown_action";msg="Unknown operation";}
 if(ok)success_++;else rejected_++;db_.audit({ip,username,action,action,ok?"allowed":code});return response(id,ok,code,msg,extra);
}
}
