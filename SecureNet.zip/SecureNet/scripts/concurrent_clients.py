#!/usr/bin/env python3
"""Small local smoke/load helper; requires Python 3 standard library only."""
import json, socket, struct, sys, threading
HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 5050
COUNT = int(sys.argv[3]) if len(sys.argv) > 3 else 20
results, lock = [], threading.Lock()
def one(i):
    try:
        payload = json.dumps({"request_id": f"load-{i}", "action": "status"}).encode()
        with socket.create_connection((HOST, PORT), timeout=4) as s:
            s.sendall(struct.pack("!I", len(payload)) + payload)
            hdr = b""
            while len(hdr) < 4:
                part = s.recv(4-len(hdr))
                if not part: raise RuntimeError("missing frame header")
                hdr += part
            n = struct.unpack("!I", hdr)[0]
            data = b""
            while len(data) < n:
                part = s.recv(n-len(data))
                if not part: raise RuntimeError("truncated response")
                data += part
        with lock: results.append((i, json.loads(data).get("success") is True, "ok"))
    except Exception as e:
        with lock: results.append((i, False, str(e)))
threads = [threading.Thread(target=one, args=(i,)) for i in range(COUNT)]
for t in threads: t.start()
for t in threads: t.join()
for row in sorted(results): print(row)
print(f"success={sum(x[1] for x in results)}/{COUNT}")
sys.exit(0 if all(x[1] for x in results) else 1)
