#!/usr/bin/env python3
"""Local end-to-end smoke test. Start the server binary supplied as argv[1]."""
import json, os, socket, struct, subprocess, sys, tempfile, time
binary = sys.argv[1] if len(sys.argv) > 1 else "./build/securenet-server"
with tempfile.TemporaryDirectory(prefix="securenet-test-") as tmp:
    db = os.path.join(tmp, "test.db")
    sock = socket.socket(); sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]; sock.close()
    proc = subprocess.Popen([binary, "--host", "127.0.0.1", "--port", str(port), "--db", db], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    def request(obj):
        payload = json.dumps(obj).encode()
        with socket.create_connection(("127.0.0.1", port), timeout=5) as s:
            s.sendall(struct.pack("!I", len(payload)) + payload)
            def exact(n):
                data = b""
                while len(data) < n:
                    part = s.recv(n-len(data))
                    if not part: raise RuntimeError("connection closed mid-frame")
                    data += part
                return data
            size = struct.unpack("!I", exact(4))[0]
            return json.loads(exact(size))
    try:
        for _ in range(50):
            if proc.poll() is not None: raise RuntimeError("server exited during startup")
            try:
                r = request({"request_id":"health","action":"status"}); break
            except OSError: time.sleep(.1)
        assert r["success"] is True, r
        assert request({"request_id":"no-auth","action":"read_data"})["code"] == "unauthenticated"
        assert request({"request_id":"bad-login","action":"login","username":"demo_user","password":"wrong"})["code"] == "authentication_failed"
        u = request({"request_id":"user-login","action":"login","username":"demo_user","password":"ChangeMe_User_123!"})
        assert u["success"] and u["role"] == "user"
        assert request({"request_id":"read","action":"read_data","token":u["token"]})["success"] is True
        assert request({"request_id":"user-admin","action":"get_stats","token":u["token"]})["code"] == "forbidden"
        a = request({"request_id":"admin-login","action":"login","username":"demo_admin","password":"ChangeMe_Admin_123!"})
        assert a["success"] and a["role"] == "admin"
        assert request({"request_id":"stats","action":"get_stats","token":a["token"]})["success"] is True
        assert request({"request_id":"audit","action":"get_audit_logs","token":a["token"]})["success"] is True
        print("PASS: status, unauthenticated rejection, failed/successful login, protected read, role denial, admin stats and audit access")
    finally:
        proc.terminate()
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: proc.kill(); proc.wait()
