# Manual integration checklist

1. Start `securenet-server` on `127.0.0.1:5050` with a fresh temporary database.
2. Send `status`; expect `success:true`.
3. Send `read_data` without a token; expect `unauthenticated`.
4. Login as demo_user and use its returned token for `read_data`; expect success.
5. Use the user token for `get_stats`; expect `forbidden`.
6. Login as demo_admin and use its token for `get_stats`; expect live counters.
7. Send `update_policy` from admin with `block_ip:"127.0.0.1"`; expect success, then observe subsequent local connections are blocked. Restart with a fresh database or change the test code to clear this process-local policy before further checks.
8. Use a small script to open concurrent clients and send status frames. Observe responses and active connections in admin statistics.
9. Inspect SQLite `audit_events`; verify outcomes exist and passwords/tokens are not present.

These are manual test instructions; do not describe them as automated or passed unless run in the target environment.
