#include "protocol.h"
#include "thread_pool.h"
#include "database.h"
#include <cassert>
#include <atomic>
#include <cstdio>
#include <iostream>
#include <thread>
#include <vector>
int main(){
 std::string err;sn::Json j;assert(sn::parse_json("{\"request_id\":\"x\",\"action\":\"status\"}",j,err));assert(sn::field(j,"action")=="status");assert(!sn::parse_json("{bad",j,err));assert(sn::json_escape("a\nb")=="a\\nb");
 std::atomic<int> n{0};{sn::ThreadPool pool(4,100);std::vector<std::thread> submitters;for(int i=0;i<4;++i)submitters.emplace_back([&]{for(int k=0;k<20;++k){while(!pool.submit([&]{++n;}))std::this_thread::yield();}});for(auto&t:submitters)t.join();pool.shutdown();}assert(n==80);
 const char* dbfile="securenet_test.db";std::remove(dbfile);{sn::Database db(dbfile);assert(db.create_user("test_user","test_hash","user"));sn::User u;assert(db.get_user("test_user",u));assert(u.hash=="test_hash");assert(db.audit({"127.0.0.1","test_user","test","status","allowed"}));assert(db.recent_audit().find("test_user")!=std::string::npos);}std::remove(dbfile);std::remove("securenet_test.db-wal");std::remove("securenet_test.db-shm");
 std::cout<<"All SecureNet unit tests passed\n";
}
