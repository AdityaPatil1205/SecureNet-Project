# SecureNet — Multi-Threaded Network Security Gateway

SecureNet is an educational C++17 TCP gateway demonstrating framed JSON messages, bounded worker threads, SQLite-backed identities/audit events, server-side sessions, role checks, IPv4 blocking, and per-IP request throttling. It is a learning project, **not** an enterprise security product or a complete Zero Trust implementation.

## Features
- TCP client/server with a 4-byte network-byte-order payload length and 64 KiB maximum frame.
- Handles partial socket reads/writes; worker count and pending queue are bounded.
- SQLite users and audit events; SQL statements use bind parameters.
- Passwords are hashed with OpenSSL's scrypt implementation and random salts. Random session tokens expire after one hour.
- `user` and `admin` roles; protected operations deny by default.
- In-memory IPv4 block list and per-IP 30 requests / 10 seconds limit.
- Counters reflect live server events; tests cover framing parsing helpers, thread pool work, and SQLite persistence.

## Architecture
```mermaid
flowchart TD
  C[Client] --> T[TCP listener]
  T --> Q[Bounded worker pool]
  Q --> F[Length-prefixed JSON framing]
  F --> A[Authentication and session lookup]
  A --> P[Role checks and IP policy]
  P --> R[Per-IP rate limiter]
  R --> H[Request handler]
  H --> D[(SQLite users and audit events)]
  H --> S[Thread-safe counters]
  H --> C
```

## Dependencies (Linux / WSL2)
- C++17 compiler, CMake, Make/Ninja
- SQLite3 development headers
- OpenSSL development headers
- Boost headers (Property Tree JSON parser)

On Debian/Ubuntu: `sudo apt install build-essential cmake libsqlite3-dev libssl-dev libboost-dev`.

## Build and test
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
```

## Run
Start the server in one terminal:
```bash
./build/securenet-server --host 127.0.0.1 --port 5050 --db securenet.db --workers 4 --queue 128
```
The first run creates synthetic demo users if they do not already exist:
- `demo_user` / `ChangeMe_User_123!` (role `user`)
- `demo_admin` / `ChangeMe_Admin_123!` (role `admin`)

These credentials are for local demonstrations only. Change/remove them before any deployment. Do not expose the server publicly; the transport has no TLS.

In another terminal:
```bash
./build/securenet-client --request '{"request_id":"1","action":"status"}'
./build/securenet-client --request '{"request_id":"2","action":"login","username":"demo_user","password":"ChangeMe_User_123!"}'
```
Copy the returned token into protected requests:
```bash
./build/securenet-client --request '{"request_id":"3","action":"read_data","token":"PASTE_TOKEN_HERE"}'
```
Admin example: login as `demo_admin`, then send `get_stats` or `get_audit_logs` with its token. To block an IPv4 address, send `update_policy` with `block_ip` from an admin session. A block affects subsequent connections from that address, so blocking `127.0.0.1` will also block your local client.

## Protocol
Every message is `uint32_be payload_length` followed by exactly that many UTF-8 JSON bytes. Payloads must be 1–65536 bytes. One request and one response are exchanged per TCP connection by the included CLI; the server can process multiple frames on a connection. Malformed frames close the connection. See [docs/protocol.md](docs/protocol.md).

## Operations
- `status`: public health status.
- `login`: requires `username` and `password`; returns a bearer `token` and role.
- `read_data`: requires a valid token.
- `get_stats`, `get_audit_logs`, `update_policy`: require a valid admin token.
- Unknown actions are rejected.

## Database schema
`users` stores username, scrypt password hash, role, active flag, and creation timestamp. `audit_events` stores timestamp, observed client IPv4, username where known, event/action, and outcome. Tokens and plaintext passwords are not persisted or written to audit rows.

## Security model and limitations
- Defaults to loopback only; supports numeric IPv4 bind addresses only. IP rules currently support exact IPv4 addresses, not CIDR or IPv6.
- No TLS/encryption in transit. Do not send real credentials over untrusted networks.
- Demo credentials are created automatically for a convenient local demo.
- Sessions and rate limits are process-local and reset on restart; rate limit is fixed at 30 requests per 10 seconds in this implementation.
- A worker handles a connection until disconnect/timeout; each client should close after a request. The bounded accept queue rejects overload with a `busy` response.
- `boost::property_tree` is used for parsing JSON. Its tree representation does not preserve every JSON scalar type distinctly, so this is intentionally a small demonstration protocol, not a strict schema-validation library.
- Graceful shutdown is currently process/terminal-driven; stop the server with Ctrl+C. A production service should add signal-safe shutdown orchestration and TLS.

## Tests and local demonstrations
```bash
ctest --test-dir build --output-on-failure
python3 scripts/smoke_test.py ./build/securenet-server
python3 scripts/concurrent_clients.py 127.0.0.1 5050 20
```
The smoke test checks status, unauthenticated rejection, failed/successful login, protected reads, role denial, and admin statistics/audit access. The concurrent-client script opens multiple local TCP connections and validates their responses. These checks do not replace security review, fuzzing, sanitizer runs, or sustained load tests.

## Repository layout
`include/` public interfaces, `src/` server/client/core implementation, `tests/` deterministic unit tests, `docs/` design notes, `config/` example settings.

## Future work
TLS, strict JSON schema validation, configurable policy files, IPv6/CIDR support, token revocation, account lockout, signal-safe shutdown, end-to-end integration tests, fuzzing, sanitizers, and CI.
